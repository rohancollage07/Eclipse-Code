package com.irctc.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.irctc.main.entity.StationData;
import com.irctc.main.inter.StationInterface;
import com.irctc.main.repository.StationRepo;

@Service       
public class StationService implements StationInterface {
	@Autowired
	StationRepo stationRepo;
	@Override
	public void addStation(StationData stationData) {
		// TODO Auto-generated method stub
		stationRepo.save(stationData);
	}

	@Override
	public List<StationData> getStations() {
		// TODO Auto-generated method stub
		return stationRepo.findAll();
	}

}
