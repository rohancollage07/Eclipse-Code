package com.irctc.main.inter;

import java.util.List;

import com.irctc.main.entity.PassengersData;


public interface PassengerInterface {
	
	public void addPassenger(PassengersData passengersData);
	
	public List<PassengersData> getPassengers();
	
	
}
