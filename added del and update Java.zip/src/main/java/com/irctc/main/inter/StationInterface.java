package com.irctc.main.inter;

import java.util.List;

import com.irctc.main.entity.StationData;


public interface StationInterface {

		public void addStation(StationData stationdata);
		
		public List<StationData> getStations();
		
}
