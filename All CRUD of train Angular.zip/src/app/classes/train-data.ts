export class TrainData {
  trainId: number
  trainName: string
  trainNumber: number

  constructor(trainId: any, trainName: any, trainNumber: any) {
    this.trainId = trainId
    this.trainName = trainName
    this.trainNumber = trainNumber
  }
}
