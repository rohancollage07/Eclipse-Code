package com.irctc.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.irctc.main.entity.TrainData;
import com.irctc.main.inter.TrainInterface;
import com.irctc.main.repository.TrainRepo;

@Service
public class TrainService implements TrainInterface{
	@Autowired
	TrainRepo trainRepo;
	
	
	@Override
	public void addTrains(TrainData train) {
		// TODO Auto-generated method stub
		trainRepo.save(train);
	}


	@Override
	public List<TrainData> getTrains() {
		// TODO Auto-generated method stub
		return trainRepo.findAll();
	}
	
	
	
	
	
	

	
	
}
