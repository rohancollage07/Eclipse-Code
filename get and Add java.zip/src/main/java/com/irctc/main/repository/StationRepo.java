//package com.irctc.main.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.irctc.main.entity.StationData;
//
//public interface StationRepo extends JpaRepository<StationData, Long> {
//
//}
