package com.irctc.main.entity;

public class StationData {

}
