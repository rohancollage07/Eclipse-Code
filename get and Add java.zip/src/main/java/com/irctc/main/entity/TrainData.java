package com.irctc.main.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;


@Entity
public class TrainData {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long trainId;
	private String trainName;
	private Long trainNumber;
	
	public TrainData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TrainData(Long trainId, String trainName, Long trainNumber) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.trainNumber = trainNumber;
	}
	public Long getTrainId() {
		return trainId;
	}
	public void setTrainId(Long trainId) {
		this.trainId = trainId;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public Long getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(Long trainNumber) {
		this.trainNumber = trainNumber;
	}
	@Override
	public String toString() {
		return "TrainData [trainId=" + trainId + ", trainName=" + trainName + ", trainNumber=" + trainNumber + "]";
	}
	
	
	

}
