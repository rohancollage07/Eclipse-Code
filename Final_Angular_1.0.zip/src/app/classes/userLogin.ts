export class userLogin {
  userEmail: String
  userPassword: String

  constructor(userEmail: String, userPassword: String) {
    this.userEmail = userEmail
    this.userPassword = userPassword
  }
}
