export class Admin{
    adminName: String;
    adminPass: String;

    constructor(adminName : String, adminPass : String){
        this.adminName = adminName;
        this.adminPass = adminPass;
    }
}