package com.transportation;

public class Airline {
	private int aId;
	private String compName;
	private int airFarePrice;
	private int seatsAvail;
	
	public Airline() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Airline(int aId, String compName, int airFarePrice, int seatsAvail) {
		super();
		this.aId = aId;
		this.compName = compName;
		this.airFarePrice = airFarePrice;
		this.seatsAvail = seatsAvail;
	}
	public int getaId() {
		return aId;
	}
	public void setaId(int aId) {
		this.aId = aId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getairFarePrice() {
		return airFarePrice;
	}
	public void setairFarePrice(int airFarePrice) {
		this.airFarePrice = airFarePrice;
	}
	public int getSeatsAvail() {
		return seatsAvail;
	}
	public void setSeatsAvail(int seatsAvail) {
		this.seatsAvail = seatsAvail;
	}
	@Override
	public String toString() {
		return "Airline [aId=" + aId + ", compName=" + compName + ", airFarePrice=" + airFarePrice + ", seatsAvail="
				+ seatsAvail + "]";
	}
	
	
}
