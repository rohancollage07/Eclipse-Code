import { Component } from '@angular/core';
import { TrainComponent } from '../train.component';
import { TrainData } from '../../../classes/train-data';

@Component({
  selector: 'app-update-train',
  standalone: true,
  imports: [],
  templateUrl: './update-train.component.html',
  styleUrl: './update-train.component.css'
})
export class UpdateTrainComponent {

  constructor(private traincomp: TrainComponent) {}

 


}
