import { Routes } from '@angular/router'
import { HomeComponent } from './components/home/home.component'
import { TrainComponent } from './components/train/train.component'
import { UpdateTrainComponent } from './components/train/update-train/update-train.component'

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'trainOperation', component: TrainComponent },
  { path: 'updateTrain', component: UpdateTrainComponent },
]
