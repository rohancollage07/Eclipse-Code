package com.irctc.main.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Entity
public class StationData {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long stationId;
	private String stationFrom;
	private String stationTo;
	private String arrivalTime;
	private String reachTime;
	private String totalTime;
	
	
	
	public StationData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StationData(long stationId, String stationFrom, String stationTo, String arrivalTime, String reachTime,
			String totalTime) {
		super();
		this.stationId = stationId;
		this.stationFrom = stationFrom;
		this.stationTo = stationTo;
		this.arrivalTime = arrivalTime;
		this.reachTime = reachTime;
		this.totalTime = totalTime;
	
	}
	public long getStationId() {
		return stationId;
	}
	public void setStationId(long stationId) {
		this.stationId = stationId;
	}
	public String getStationFrom() {
		return stationFrom;
	}
	public void setStationFrom(String stationFrom) {
		this.stationFrom = stationFrom;
	}
	public String getStationTo() {
		return stationTo;
	}
	public void setStationTo(String stationTo) {
		this.stationTo = stationTo;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getReachTime() {
		return reachTime;
	}
	public void setReachTime(String reachTime) {
		this.reachTime = reachTime;
	}
	public String getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}
	
	@Override
	public String toString() {
		return "StationData [stationId=" + stationId + ", stationFrom=" + stationFrom + ", stationTo=" + stationTo
				+ ", arrivalTime=" + arrivalTime + ", reachTime=" + reachTime + ", totalTime=" + totalTime + "]";
	}
	
	
	
	
}
