package com.irctc.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.irctc.main.entity.StationData;
import com.irctc.main.entity.TrainData;
import com.irctc.main.inter.StationInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("/stations")
public class StationController {
	
	private final StationInterface stationInterface;
	
	@Autowired
	public  StationController(StationInterface stationInterface) {
		this.stationInterface=stationInterface;
	}
	
	@PostMapping("/addStations")
	public void addStations(@RequestBody StationData station) {
		System.out.println(station);
		stationInterface.addStation(station);	
	}
	

	@GetMapping("/getStations")
	public List<StationData> getStations(){
		return stationInterface.getStations();
	}
}
