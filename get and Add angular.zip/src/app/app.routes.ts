import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { TrainComponent } from './components/train/train.component';

export const routes: Routes = [
 {path : '',
    component:HomeComponent }
,
 {path : 'trainOperation',
    component: TrainComponent}    
     
];
