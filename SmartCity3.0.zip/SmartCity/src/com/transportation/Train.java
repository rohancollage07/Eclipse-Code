package com.transportation;

public class Train {
	private int tiD;
	private String tName;
	private double tNumber;
	private int tfarePrice;
	private int tseatsAvail;
	public Train() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Train(int tiD, String tName, double tNumber, int tfarePrice, int tseatsAvail) {
		super();
		this.tiD = tiD;
		this.tName = tName;
		this.tNumber = tNumber;
		this.tfarePrice = tfarePrice;
		this.tseatsAvail = tseatsAvail;
	}
	public int getTiD() {
		return tiD;
	}
	public void setTiD(int tiD) {
		this.tiD = tiD;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public double gettNumber() {
		return tNumber;
	}
	public void settNumber(double tNumber) {
		this.tNumber = tNumber;
	}
	public int getTfarePrice() {
		return tfarePrice;
	}
	public void setTfarePrice(int tfarePrice) {
		this.tfarePrice = tfarePrice;
	}
	public int getTseatsAvail() {
		return tseatsAvail;
	}
	public void setTseatsAvail(int tseatsAvail) {
		this.tseatsAvail = tseatsAvail;
	}
	@Override
	public String toString() {
		return "Train [tiD=" + tiD + ", tName=" + tName + ", tNumber=" + tNumber + ", tfarePrice=" + tfarePrice
				+ ", tseatsAvail=" + tseatsAvail + "]";
	}
	
	
	
	

}
