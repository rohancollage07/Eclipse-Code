package com.dao;

import java.util.ArrayList;
import java.util.Arrays;

import com.Shopping.Malls;
import com.acommodation.Hotels;
import com.entity.Admin;
import com.entity.User;
import com.news.News;
import com.transportation.Airline;
import com.transportation.Cabs;
import com.transportation.Train;

public class Dao {
	
	//Admin
	
ArrayList<Admin> AdminDetails = new ArrayList<>(Arrays.asList(
			
			new Admin(17007)
			
			
			)
			
			);
	public ArrayList<Admin> fetchPass(){
		return AdminDetails;
	}
	
	//User Login
	
ArrayList<User> userDetails = new ArrayList<>(Arrays.asList(
			
			new User("rohan", "BlackHammer"),
			new User("vishal","DeadShot")
			
			)
			
			);

	public ArrayList<User> fetchUsers() {
	return userDetails;

}
	
	public void registerUser(String username, String password) {
		User newUser = new User(username, password);
	    userDetails.add(newUser);
	}
	
	//HotelsData
	ArrayList<Hotels> hList = new ArrayList<>(Arrays.asList(
			
			new Hotels(1,"ssbstay","street 1",
			"mankhurd",200,3),
			new Hotels(2,"akhotels","street 2",
					"chembur",250,4),
			
			new Hotels(3,"Swami","street 3",
					"Vashi",100,2)
			
			)
			
			);
		
	public ArrayList<Hotels> fetchHotels() {
		return hList;

	}
	
	//NewsData
	ArrayList<News> nList = new ArrayList<>(Arrays.asList(
			
			new News(1, "Army personal dead at Kashmir", "Another jawan died on Thursday in the ongoing encounter between terrorists and security forces in Jammu and Kashmir's Rajouri district. This has taken the number of total Army personnel killed since yesterday to five.\r\n"
					+ "\r\n"
					+ "Four Army personnel were killed on Wednesday, which included two captains and two jawans."),
			
			new News(2, "People found who were missing in the tunnel",
					"A senior member of the National Disaster Management "
					+ "Authority (NDMA) on Thursday warned the masses "
					+ "against putting pressure on the rescue teams with "
					+ "their expectations of a hasty rescue of the 41 workers "
					+ "trapped in a partially collapsed tunnel in "
					+ "Uttarkashi. Lt General (retired) Syed Ata Hasnain, addressing a "
					+ "press conference, pointed out that the trapped workers and the rescuers are at equal risk and expecting the rescue operation to be "
					+ "completed in the “next two hours” exerts pressure on the latter. ")
			
			)
			
			);
	
	public ArrayList<News> fetchNews() {
		return nList;

	}
	
	//MallsData
	
	ArrayList<Malls> mList = new ArrayList<>(Arrays.asList(new Malls(1,"Seawoods","Seawoods Station"),
			new Malls(2,"Inorbit","Vashi Station")
			)
			);
	
	public ArrayList<Malls> fetchMalls(){
		return mList;
	}

	
	//Transportation Data
	
	//Cabs Data
	ArrayList<Cabs> cList 
	= new ArrayList<>
	(Arrays.asList(
			new Cabs(1,"vishal","Innova","MH01",8,30),
			new Cabs(2,"sham","BMW","MH01",4,100),
			new Cabs(3,"isha","Audi","MH01",4,300)
			)
			);
	
	public ArrayList<Cabs> fetchCabs(){
		return cList;
	}
	
	
	
	//Train Data
	ArrayList<Train> tList 
	= new ArrayList<>
	(Arrays.asList(
			new Train(1,"Kamayani Express",10421,350,121),
			new Train(2,"Latur Express",22145,200,50),
			new Train(3,"Delhi",330112,500,11)
			)
			);
	
	public ArrayList<Train> fetchTrains(){
		return tList;
	}

	
	//Airline Data
	
	ArrayList<Airline> aList 
	= new ArrayList<>
	(Arrays.asList(
			new Airline(1,"Air India",4000,35),
			new Airline(2,"Indigo",5000,62),
			new Airline(3,"Spice Jet",6000,88),
			new Airline(4,"Bloomberg",2000,5)
			)
			);
	
	public ArrayList<Airline> fetchAirlines(){
		return aList;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
