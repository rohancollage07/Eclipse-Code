package com.controller;

import java.util.Scanner;

import com.service.Service;

public class Controller {
	
	static Service service = new Service();
	
	public static void filterByPrice() {
		service.filterByPrice();
	}
	
	public static void filterByArea() {
		service.filterByArea();
	}
	
	public static void bookHotel(int hId) {
		service.bookHotelById(hId);
	}
	
	public static void cancelHotel(int hId) {
		service.cancelHotelById(hId);
	}
	
	public static void fetchNews() {
		service.fetchNews();
	}
	
	public static void filterNewsById(int nId) {
		service.filterNewsById(nId);
	}
	
	public static void fetchMalls() {
		service.fetchMalls();
	}
	
	public static void fetchCabs() {
		service.fetchCabs();
	}
	
	public static void fetchAirlines() {
		service.fetchAirlines();
	}
	
	public static void fetchTrains() {
		service.fetchTrains();
	}
	
	public static boolean adminPassMatch(int pass) {
		return service.adminPassMatch(pass);
	}
	
	
	public static void registerUser(String username, String password) {
		
		service.registerUser(username, password);
		service.refreshData();
	}
	
	public static boolean isUserPresent(String username, String password) {
		return service.isUser(username, password);
	}
	
	public static void callLoginPage() {
		Scanner in = new Scanner(System.in);
		System.out.println();
		System.out.println("Enter Login Credentials");
		System.out.println("Enter Username : ");
		String username = in.nextLine();
		System.out.println("Enter Password: ");
		String password = in.nextLine();
		System.out.println();
		boolean isPresent = isUserPresent(username,password);
		System.out.println(isPresent);
		if(isPresent) {
			alloperation();
			mainMenu();
		}else {
			System.out.println("Wrong Username or Password try Again");
		}
		
	}
	
	public static void mainMenu() {
		Scanner in = new Scanner(System.in);
		System.out.println("Choose Options: ");
		System.out.println("User Login : 1");
		System.out.println("User Register : 2");
		System.out.println("Admin : 3");
		System.out.println("Exit: 4");
		int choice = in.nextInt();
		in.nextLine();
		switch (choice) {
		case 1:
			callLoginPage();
			
			break;
		
		case 2:
//			Scanner in = new Scanner(System.in);
			System.out.println();
			System.out.println("Fill Register Credentials");
			System.out.println("Set Username : ");
			String username2 = in.nextLine();
			System.out.println("Set Password: ");
			String password2 = in.nextLine();
			System.out.println();
			
			registerUser(username2, password2);
			callLoginPage();
			
			
			break;
		case 3:
			System.out.println("Enter admin password :");
			int pass = in.nextInt();
			if(adminPassMatch(pass)) {
				System.out.println("Welcome admin");
			}else {
				System.out.println("Wrong Password ! Get Out !");
				mainMenu();
			}
			//admin related
			
			//Add Hotels
			
			// Update Hotels
			// Delete Hotels
			//Add Trains
			// Update Trains
			// Delete Trains
			//Add AIrlines
			// Update Airlines
			// Delete Airlines
			//Add Cabs
			// Update Cabs
			// Delete Cabs
			
			break;
		case 4:
			System.out.println("Thank you for visiting Rohan's City ");
			
			break;
		default:
			break;
		}
		
		
	}
	
	public static void alloperation() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Rohan's City ! What would you explore : ");
		System.out.println();
		System.out.print("Hotel ? press 1 ");
		System.out.println();
		System.out.print("City News ? press 2 ");
		System.out.println();
		System.out.print("Malls to Shop? press 3");
		System.out.println();
		System.out.print("Transportations ? press 4");
		System.out.println();
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			
			service.fetchHotels();
			System.out.println();
			System.out.println("filter hotels : ");
			System.out.println();
			System.out.println("price ? press 1");
			
			System.out.println("area ? press 2 ");
			int choice2 = sc.nextInt();
			
			switch (choice2) {
			case 1:
				filterByPrice();
				
				break;
			case 2 : 
				filterByArea();
				break;

			default:
				break;
			}
			
			System.out.println("which hotel to book? Enter id : ");
			int hId = sc.nextInt();
			
			bookHotel(hId);
			
			System.out.println("which hotel to Cancel? Enter id : ");
			int hId2 = sc.nextInt();
			
			cancelHotel(hId2);
			
			break;
		case 2: 
			
			fetchNews();
			
			System.out.println();
			
			System.out.println("which story would you like to read fully ? ");
			System.out.print("Enter ID: ");
			
			int nId = sc.nextInt();
			
			filterNewsById(nId);
			
			System.out.println();
			break;
		
		case 3 : 
			fetchMalls();
			break;
		
		case 4:
			System.out.println("which transport options to explore : ");
			System.out.println();
			System.out.println("Cabs :  Press 1 :  ");
			System.out.println("Trains : Press 2 :  ");
			System.out.println("Airlines : Press 3 :  ");
			System.out.println();
			
			int trans_choice = sc.nextInt();
			
			switch (trans_choice) {
			case 1 :
				fetchCabs();
				break;
			
			case 2 :
				fetchTrains();
				break;
			
			case 3 :
				
				fetchAirlines();
				break;
			default:
				break;
			}
			
			break;
			
		default:
			break;
		}
		

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		mainMenu();
		
		
		
	}

}
