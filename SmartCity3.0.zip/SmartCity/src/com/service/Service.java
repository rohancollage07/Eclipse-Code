package com.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

import com.Shopping.Malls;
import com.acommodation.Hotels;
import com.dao.Dao;
import com.entity.Admin;
import com.entity.User;
import com.news.News;
import com.transportation.Airline;
import com.transportation.Cabs;
import com.transportation.Train;

public class Service {
	static Dao da = new Dao();
	
	//All list Retrived from Dao at one place
	
	public static ArrayList<Hotels> hlist  = da.fetchHotels();
	public static ArrayList<News> nList  = da.fetchNews();
	public static ArrayList<Malls> mlist = da.fetchMalls();
	public static ArrayList<Cabs> clist = da.fetchCabs();
	public static ArrayList<Airline> alist = da.fetchAirlines();
	public static ArrayList<Train> tlist = da.fetchTrains();
	public static ArrayList<User> userDetails = da.fetchUsers();
	public static ArrayList<Admin> AdminDetails = da.fetchPass();
	
	public static void refreshData() {
        hlist = da.fetchHotels();
        nList = da.fetchNews();
        mlist = da.fetchMalls();
        clist = da.fetchCabs();
        alist = da.fetchAirlines();
        tlist = da.fetchTrains();
        userDetails = da.fetchUsers();
    }
	
	
	public boolean adminPassMatch(int pass) {
		return AdminDetails.stream().anyMatch(x -> x.getAdminPass() == pass);
	}
	
	
	
	
	//User
	
	public void registerUser(String username, String password) {
		da.registerUser(username, password);
	}
	
	public boolean isUser(String username, String password) {
		return userDetails.stream().anyMatch(x -> x.getUserName().equals(username) && x.getUserPass().equals(password));
	
	}
	
	
	
	
	// HOTEL OPERATION BELOW
	
	public void fetchHotels() {
		
		hlist.forEach(System.out::println);
	}
	
	public void filterByPrice() {
		hlist.stream().sorted(Comparator.comparingInt(Hotels::gethPrice)).forEach(System.out::println);
		System.out.println();
	}
	
	public void filterByArea() {
		hlist.stream().sorted(Comparator.comparing(Hotels::gethArea, String.CASE_INSENSITIVE_ORDER)).forEach(System.out::println);
		
	}
	
	public void bookHotelById(int hId) {
		String result = hlist.stream()
			    .filter(x -> x.gethId() == hId)
			    .map(x -> "Booked hotel at : " + x.gethName()+ " Happy Stay !")
			    .findFirst()
			    .orElse("No hotel found with ID : " + hId + " Try Again");
	
			System.out.println(result);
			System.out.println();

	
	}
	
	
	public void cancelHotelById(int hId) {
		String result = hlist.stream()
			    .filter(x -> x.gethId() == hId)
			    .map(x -> "Booking cancel at : " + x.gethName()+ ", No problem visit next time")
			    .findFirst()
			    .orElse("No hotel found with ID : " + hId + " Try Again");
	
			System.out.println(result);
			System.out.println();
	
	}
	
	//NEW OPERATION BELOW
	
	public void fetchNews() {
		
//		nList.forEach(System.out::println);
		nList.stream().map(x -> x.getNewsID() + " " +  x.getNewsStory()).collect(Collectors.toList()).forEach(System.out::println);;
	}
	
	
	public void filterNewsById(int nId) {
		 nList.stream().filter(x -> x.getNewsID() == nId).map(x -> x.getFullStory()).collect(Collectors.toList()).forEach(System.out::println);
		
	}
	
	
	// MALLS OPERATION BELOW
	
	public void fetchMalls() {
		mlist.forEach(System.out::println);
		
	}
	
	//Transportation Operation Below
	
	//Cabs
	public void fetchCabs() {
		clist.forEach(System.out::println);
		
	}
	
	//Airlines
		public void fetchAirlines() {
			alist.forEach(System.out::println);
			
		}

	//Trains
	public void fetchTrains() {
		tlist.forEach(System.out::println);
					
	}

	
	
	
	
	
}


