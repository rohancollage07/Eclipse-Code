package com.transportation;

public class Cabs {
	private int cId;
	private String driverName;
	private String cabmodel;
	private String cabNum;
	private int seater;
	private int cFarePrice;
	
	public Cabs() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Cabs(int cId, String driverName, String cabmodel, String cabNum, int seater, int cfarePrice) {
		super();
		this.cId = cId;
		this.driverName = driverName;
		this.cabmodel = cabmodel;
		this.cabNum = cabNum;
		this.seater = seater;
		this.cFarePrice = cfarePrice;
	}



	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getCabmodel() {
		return cabmodel;
	}

	public void setCabmodel(String cabmodel) {
		this.cabmodel = cabmodel;
	}

	public String getCabNum() {
		return cabNum;
	}

	public void setCabNum(String cabNum) {
		this.cabNum = cabNum;
	}

	public int getSeater() {
		return seater;
	}

	public void setSeater(int seater) {
		this.seater = seater;
	}

	public int getcFarePrice() {
		return cFarePrice;
	}



	public void setcFarePrice(int farePrice) {
		this.cFarePrice = farePrice;
	}



	@Override
	public String toString() {
		return "Cabs : " + cId + "\n"
				+ "Driver's name: " + driverName + "\n" 
				+ "Cab model : " + cabmodel + "\n"
				+ "Cab Number : " + cabNum + "\n"
				+ "Seater: " + seater + "\n"
				+ "Cab Fare Price Per Km : " + cFarePrice + "\n";
	}
	
	

}
