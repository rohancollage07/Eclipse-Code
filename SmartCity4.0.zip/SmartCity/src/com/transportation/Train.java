package com.transportation;

public class Train {
	private int tiD;
	private String tName;
	private int tNumber;
	private int tfarePrice;
	private int tseatsAvail;
	public Train() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Train(int tiD, String tName, int tNumber, int tfarePrice, int tseatsAvail) {
		super();
		this.tiD = tiD;
		this.tName = tName;
		this.tNumber = tNumber;
		this.tfarePrice = tfarePrice;
		this.tseatsAvail = tseatsAvail;
	}
	public int getTiD() {
		return tiD;
	}
	public void setTiD(int tiD) {
		this.tiD = tiD;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public int gettNumber() {
		return tNumber;
	}
	public void settNumber(int tNumber) {
		this.tNumber = tNumber;
	}
	public int getTfarePrice() {
		return tfarePrice;
	}
	public void setTfarePrice(int tfarePrice) {
		this.tfarePrice = tfarePrice;
	}
	public int getTseatsAvail() {
		return tseatsAvail;
	}
	public void setTseatsAvail(int tseatsAvail) {
		this.tseatsAvail = tseatsAvail;
	}
	@Override
	public String toString() {
		return "Train : " + tiD + "\n"
				+ "Train Name : " + tName + "\n" 
				+ "Train Number : " + tNumber + "\n"
				+ "Train Fare Price Per Km : " + tfarePrice + "\n"
				+ "Seats Available : " + tseatsAvail + "\n";
	}
	
	
	
	

}
