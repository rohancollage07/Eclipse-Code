package com.controller;

import java.util.Scanner;

import com.service.Service;

public class Controller {
	
	static Service service = new Service();
	
	
	public static void addHotels() {
		Scanner ad = new Scanner(System.in);
		System.out.println();
		System.out.println("enter hotel details : " );
		System.out.println("enter hotel id: ");
		int id = ad.nextInt();
		ad.nextLine();
		System.out.println("Enter Hotel Name : ");
		String name = ad.nextLine();
		System.out.println("Enter Address : ");
		String address = ad.nextLine();
		System.out.println("Enter Area : ");
		String area = ad.nextLine();
		System.out.println("Enter price per room : ");
		int price = ad.nextInt();
		ad.nextLine();
		System.out.println("Enter Room Available : ");
		int room = ad.nextInt();
		System.out.println();
		
		service.addHotels(id,name,address,area,price,room);
		System.out.println("Hotel "+ name + " added to list ");
		
		
		
	}
	
	
	public static void filterByPrice() {
		service.filterByPrice();
	}
	
	public static void filterByArea() {
		service.filterByArea();
	}
	
	public static void bookHotel(int hId) {
		service.bookHotelById(hId);
	}
	
	public static void cancelHotel(int hId) {
		service.cancelHotelById(hId);
	}
	
	public static void fetchNews() {
		service.fetchNews();
	}
	
	public static void filterNewsById(int nId) {
		service.filterNewsById(nId);
	}
	
	public static void fetchMalls() {
		service.fetchMalls();
	}
	
	public static void fetchCabs() {
		service.fetchCabs();
	}
	
	public static void bookCabById(int cabId) {
		service.bookCabById(cabId);
	}
	
	public static void fetchTrains() {
		service.fetchTrains();
	}
	
	public static void bookTrainById(int trainId) {
		service.bookTrainById(trainId);
	}
	
	public static void fetchAirlines() {
		service.fetchAirlines();
	}
	
	public static void bookAirticketById(int airId) {
		service.bookAirticketById(airId);
	}
	
	
	
	public static void AtmInterface() {
		Scanner at = new Scanner(System.in);
		System.out.println();
		System.out.println("Welcome to Rohan's Bank");
		System.out.println();
		System.out.println("Enter ATM Number : ");
		int atmNum = at.nextInt();
		System.out.println("Enter ATM Password : ");
		int atmPass = at.nextInt();
		
		if(service.atmPassMatch(atmNum,atmPass)) {
			System.out.println();
			System.out.println("What do you want to do ? ");
			System.out.println();
			System.out.println("Check Balance ? Press 1 : ");
			System.out.println("Withdraw balance ? Press 2:  ");
			int choice = at.nextInt();
			switch (choice) {
			case 1:
				System.out.println();
				System.out.println("The Balance is : ");
				service.checkBalance(atmNum);
				System.out.println();
				
				System.out.println("Enter Amount to withdraw");
				int amt1 = at.nextInt();
				service.withdrawAmount(atmNum,amt1);
				alloperation();
				break;
			case 2: 
				System.out.println();
				System.out.println("Enter Amount to withdraw");
				int amt = at.nextInt();
				service.withdrawAmount(atmNum,amt);
				alloperation();
				break;
			default:
				break;
			}
		}
		
	}
	

	
	public static boolean adminPassMatch(int pass) {
		return service.adminPassMatch(pass);
	}
	
	
	public static void registerUser(String username, String password) {
		
		service.registerUser(username, password);
		service.refreshData();
	}
	
	public static boolean isUserPresent(String username, String password) {
		return service.isUser(username, password);
	}
	
	public static void callLoginPage() {
		Scanner in = new Scanner(System.in);
		System.out.println();
		System.out.println("Enter Login Credentials");
		System.out.println("Enter Username : ");
		String username = in.nextLine();
		System.out.println("Enter Password: ");
		String password = in.nextLine();
		System.out.println();
		boolean isPresent = isUserPresent(username,password);
		
		if(isPresent) {
			alloperation();
			
		}else {
			System.out.println("Wrong Username or Password try Again");
			callLoginPage();
		}
		
	}
	
	public static void mainMenu() {
		Scanner in = new Scanner(System.in);
		System.out.println("Choose Options: ");
		System.out.println("User Login : 1");
		System.out.println("User Register : 2");
		System.out.println("Admin : 3");
		System.out.println("Exit: 4");
		int choice = in.nextInt();
		in.nextLine();
		switch (choice) {
		case 1:
			callLoginPage();
			
			break;
		
		case 2:
//			Scanner in = new Scanner(System.in);
			System.out.println();
			System.out.println("Fill Register Credentials");
			System.out.println("Set Username : ");
			String username2 = in.nextLine();
			System.out.println("Set Password: ");
			String password2 = in.nextLine();
			System.out.println();
			
			registerUser(username2, password2);
			callLoginPage();
			
			
			break;
		case 3:
			System.out.println("Enter admin password :");
			int pass = in.nextInt();
			if(adminPassMatch(pass)) {
				System.out.println("Welcome admin");
				adminOptions();
				
				
			}else {
				System.out.println("Wrong Password ! Get Out !");
				mainMenu();
			}
			//admin related
			
			//Add Hotels
			
			// Update Hotels
			// Delete Hotels
			//Add Trains
			// Update Trains
			// Delete Trains
			//Add AIrlines
			// Update Airlines
			// Delete Airlines
			//Add Cabs
			// Update Cabs
			// Delete Cabs
			
			break;
		case 4:
			System.out.println("Thank you for visiting Rohan's City ");
			
			break;
		
		default:
			break;
		}
		
		
	}
	
	public static void alloperation() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Rohan's City ! What would you explore : ");
		System.out.println();
		System.out.print("Hotel ? press 1 ");
		System.out.println();
		System.out.print("City News ? press 2 ");
		System.out.println();
		System.out.print("Malls to Shop? press 3");
		System.out.println();
		System.out.print("Transportations ? press 4");
		System.out.println();
		System.out.print("ATM ? press 5");
		System.out.println();
		System.out.print("Exit ? press 6");
		System.out.println();
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			
			service.fetchHotels();
			System.out.println();
			System.out.println("filter hotels by  : ");
			System.out.println("price ? press 1");
			
			System.out.println("area ? press 2 ");
			int choice2 = sc.nextInt();
			
			switch (choice2) {
			case 1:
				filterByPrice();
				
				break;
			case 2 : 
				filterByArea();
				break;
			
			default:
				break;
			}
			
			System.out.println("which hotel to book? Enter id : ");
			int hId = sc.nextInt();
			
			bookHotel(hId);
			
			System.out.println("which hotel to Cancel? Enter id : ");
			int hId2 = sc.nextInt();
			
			cancelHotel(hId2);
			alloperation();
			break;
		case 2: 
			
			fetchNews();
			
			System.out.println();
			
			System.out.println("which story would you like to read fully ? ");
			System.out.print("Enter ID: ");
			
			int nId = sc.nextInt();
			System.out.println();
			filterNewsById(nId);
			
			System.out.println();
			alloperation();
			break;
		
		case 3 : 
			fetchMalls();
			alloperation();
			break;
		
		case 4:
			System.out.println("which transport options to explore : ");
			System.out.println();
			System.out.println("Cabs :  Press 1 :  ");
			System.out.println("Trains : Press 2 :  ");
			System.out.println("Airlines : Press 3 :  ");
			System.out.println();
			
			int trans_choice = sc.nextInt();
			
			switch (trans_choice) {
			case 1 :
				fetchCabs();
				System.out.println("Which Cab To Book Sir : Enter ID : ");
				int cabId = sc.nextInt(); 
				bookCabById(cabId);
				break;
			
			case 2 :
				fetchTrains();
				System.out.println("Which Train To Book Sir : Enter ID : ");
				int trainId = sc.nextInt(); 
				bookTrainById(trainId);
				
				break;
			
			case 3 :
				fetchAirlines();
				System.out.println("Which Airlines To Book Sir : Enter ID : ");
				int airId = sc.nextInt(); 
				bookAirticketById(airId);
				break;
			default:
				break;
			}
			alloperation();
			break;
		case 5 : 
			AtmInterface();
			
			break;
		case 6 : 
			System.out.println();
			System.out.println("Thank You");
			System.out.println();
			mainMenu();
			break;
			
		default:
			break;
		}
		

	}
	
	public static void adminOptions() {
		Scanner op = new Scanner(System.in);
		
		System.out.println();
		System.out.println("What do you want to do : ");
		System.out.println("Perform Hotel Operation ? Press 1 ");
		System.out.println("Perform News Operation ? Press 2 ");
		System.out.println("Perform Malls Operation ? Press 3 ");
		System.out.println("Perform Train Operation ? Press 4 ");
		System.out.println("Perform Airlines Operation ? Press 5 ");
		System.out.println("Perform Cabs Operation ? Press 6 ");
		int choice = op.nextInt();
		System.out.println();

		switch (choice) {
		case 1:
			hotelAdminOperation();
			break;

		default:
			break;
		}
	}
	
	public static void hotelAdminOperation() {
		Scanner hot = new Scanner(System.in);
		System.out.println();
		System.out.println("what would you like to do ?");
		System.out.println("Add hotels ? Press 1 ");
		System.out.println("Update hotels ? Press 2 ");
		System.out.println("Delete hotels ? Press 3 ");
		int choice = hot.nextInt();
		System.out.println();
		
		switch (choice) {
		case 1:
			addHotels();
			service.fetchHotels();
			adminOptions();
			
			break;
		case 2 :
			
			break;
		case 3 :
			
			break;
		default:
			break;
		}

	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		mainMenu();
		
		
		
	}

}
