package com.Shopping;

public class Malls {
	private int mId;
	private String mName;
	private String mAddress;
	
	public Malls() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Malls(int mId, String mName, String mAddress) {
		super();
		this.mId = mId;
		this.mName = mName;
		this.mAddress = mAddress;
	}

	public int getmId() {
		return mId;
	}

	public void setmId(int mId) {
		this.mId = mId;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getmAddress() {
		return mAddress;
	}

	public void setmAddress(String mAddress) {
		this.mAddress = mAddress;
	}

	@Override
	public String toString() {
		return "Malls : " + mId + "\n"
				+ "Mall Name : " + mName + "\n" 
				+ "Mall Address : " + mAddress + "\n";
	}
	
	
	
	

}
