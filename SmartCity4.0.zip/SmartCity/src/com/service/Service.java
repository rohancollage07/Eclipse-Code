package com.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.Shopping.Malls;
import com.acommodation.Hotels;
import com.dao.Dao;
import com.entity.Admin;
import com.entity.User;
import com.news.News;
import com.payments.Atm;
import com.transportation.Airline;
import com.transportation.Cabs;
import com.transportation.Train;

public class Service {
	static Dao da = new Dao();

	// All list Retrived from Dao at one place

	public static ArrayList<Hotels> hlist = da.fetchHotels();
	public static ArrayList<News> nList = da.fetchNews();
	public static ArrayList<Malls> mlist = da.fetchMalls();
	public static ArrayList<Cabs> clist = da.fetchCabs();
	public static ArrayList<Airline> alist = da.fetchAirlines();
	public static ArrayList<Train> tlist = da.fetchTrains();
	public static ArrayList<User> userDetails = da.fetchUsers();
	public static ArrayList<Admin> AdminDetails = da.fetchPass();
	public static ArrayList<Atm> atlist = da.fetchAtmData();

	public static void refreshData() {
		hlist = da.fetchHotels();
		nList = da.fetchNews();
		mlist = da.fetchMalls();
		clist = da.fetchCabs();
		alist = da.fetchAirlines();
		tlist = da.fetchTrains();
		userDetails = da.fetchUsers();
		
	}

	public boolean adminPassMatch(int pass) {
		return AdminDetails.stream().anyMatch(x -> x.getAdminPass() == pass);
	}

	// User

	public void registerUser(String username, String password) {
		da.registerUser(username, password);
	}

	public boolean isUser(String username, String password) {
		return userDetails.stream().anyMatch(x -> x.getUserName().equals(username) && x.getUserPass().equals(password));

	}

	// HOTEL OPERATION BELOW

	public void fetchHotels() {

		hlist.forEach(System.out::println);
	}

	public void filterByPrice() {
		hlist.stream().sorted(Comparator.comparingInt(Hotels::gethPrice)).forEach(System.out::println);
		System.out.println();
	}

	public void filterByArea() {
		hlist.stream().sorted(Comparator.comparing(Hotels::gethArea, String.CASE_INSENSITIVE_ORDER))
				.forEach(System.out::println);

	}

	public void bookHotelById(int hId) {
		String result = hlist.stream().filter(x -> x.gethId() == hId)
				.map(x -> "Booked hotel at : " + x.gethName() + "\n" + "Happy Stay !").findFirst()
				.orElse("No hotel found with ID : " + hId + " Try Again");

		System.out.println(result);
		System.out.println();

	}

	public void cancelHotelById(int hId) {
		String result = hlist.stream().filter(x -> x.gethId() == hId)
				.map(x -> "Booking cancel at : " + x.gethName() + "\n" + "No problem visit next time").findFirst()
				.orElse("No hotel found with ID : " + hId + " Try Again");

		System.out.println(result);
		System.out.println();

	}

	public void addHotels(int id, String name, String add, String area, int price, int room) {
		da.addHotels(id, name, add, area, price, room);
	}

	// NEW OPERATION BELOW

	public void fetchNews() {

//		nList.forEach(System.out::println);
		nList.stream().map(x -> x.getNewsID() + " " + x.getNewsStory()).collect(Collectors.toList())
				.forEach(System.out::println);
		;
	}

	public void filterNewsById(int nId) {
		nList.stream().filter(x -> x.getNewsID() == nId).map(x -> x.getFullStory()).collect(Collectors.toList())
				.forEach(System.out::println);

	}

	// MALLS OPERATION BELOW

	public void fetchMalls() {
		mlist.forEach(System.out::println);

	}

	// Transportation Operation Below

	// Cabs
	public void fetchCabs() {
		clist.forEach(System.out::println);

	}

	public void bookCabById(int cabId) {
		if (clist.stream().anyMatch(x -> x.getcId() == cabId)) {
			System.out.println();
			System.out.println("Your Cab is Booked ! " + "Please check email for eticket ");
			System.out.println("Cab details are as below , " + "Happy Travelling !");
			System.out.println();
			clist.stream().filter(x -> x.getcId() == cabId).forEach(System.out::println);
		} else {
			System.out.println("Cab ID " + cabId + " Does not Exist in List, Try Again ");
			System.out.println();
			Scanner sc = new Scanner(System.in);
			System.out.println("Which Cab To Book Sir : Enter ID : ");
			int newCabId = sc.nextInt();
			bookCabById(newCabId);
		}

	}

	// Airlines
	public void fetchAirlines() {
		alist.forEach(System.out::println);

	}

	public void bookAirticketById(int airId) {
		if (alist.stream().anyMatch(x -> x.getaId() == airId)) {
			System.out.println();
			System.out.println("Your Air Tickect is Booked ! " + "Please check email for eticket ");
			System.out.println("Airline details are as below , " + "Happy Flying !");
			System.out.println();
			alist.stream().filter(x -> x.getaId() == airId).forEach(System.out::println);
		} else {
			System.out.println("Airline ID " + airId + " Does not Exist in List, Try Again ");
			System.out.println();
			Scanner sc = new Scanner(System.in);
			System.out.println("Which Airline To Book Sir : Enter ID : ");
			int newAirId = sc.nextInt();
			bookAirticketById(newAirId);
		}
	}

	// Trains
	public void fetchTrains() {
		tlist.forEach(System.out::println);

	}

	public void bookTrainById(int trainId) {
		if (tlist.stream().anyMatch(x -> x.getTiD() == trainId)) {
			System.out.println();
			System.out.println("Your Train is Booked ! Please check email for eticket ");
			System.out.println("Train details are as below , Happy journey !");
			System.out.println();
			tlist.stream().filter(x -> x.getTiD() == trainId).forEach(System.out::println);
		} else {
			System.out.println("Train ID " + trainId + " Does not Exist in List, Try Again ");
			System.out.println();
			Scanner sc = new Scanner(System.in);
			System.out.println("Which Train To Book Sir : Enter ID : ");
			int newTrainId = sc.nextInt();
			bookTrainById(newTrainId);
		}

	}
	
	//ATM 
	
	public boolean atmPassMatch(int atmNum, int atmPass) {
		return atlist.stream().anyMatch(x -> x.getAtmNum() == atmNum && x.getAtmPass() == atmPass);
	}
	
	public void checkBalance(int atmNum) {
	    // Assuming Atm is the class name and getAtmBalance() returns the balance
	    OptionalInt balance = atlist.stream()
	            .filter(x -> x.getAtmNum() == atmNum)
	            .mapToInt(Atm::getAtmBalance)
	            .findFirst();
	    
	    
	    if (balance.getAsInt() != -1) {
	    	 System.out.println(balance.getAsInt());
	    } else {
	    	System.out.println("Amt not found");
	        // Return a specific value to indicate that the ATM number was not found
	         // or throw an exception or handle the case accordingly
	    }
	}
	
	public void withdrawAmount(int atmNum, int withdrawalAmount) {
	    Optional<Atm> atmOptional = atlist.stream()
	            .filter(x -> x.getAtmNum() == atmNum)
	            .findFirst();

	    if (atmOptional.isPresent()) {
	        Atm atm = atmOptional.get();
	        int currentBalance = atm.getAtmBalance();

	        if (currentBalance >= withdrawalAmount) {
	            // Sufficient balance, proceed with withdrawal
	            atm.setAtmBalance(currentBalance - withdrawalAmount);
	            System.out.println();
	            System.out.println("Withdrawal successful of amount : "+ withdrawalAmount + "\n"+ "Remaining balance: " + atm.getAtmBalance());
	            System.out.println();
	        } else {
	            // Insufficient balance
	        	 System.out.println();
	            System.out.println("Insufficient balance. Unable to withdraw.");
	        }
	    } else {
	        // ATM not found
	    	 System.out.println();
	        System.out.println("ATM not found. Unable to withdraw.");
	    }
	}

	


}
