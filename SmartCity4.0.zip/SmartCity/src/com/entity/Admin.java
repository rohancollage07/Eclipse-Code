package com.entity;

public class Admin {
	private int adminPass;

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int adminPass) {
		super();
		this.adminPass = adminPass;
	}

	public int getAdminPass() {
		return adminPass;
	}

	public void setAdminPass(int adminPass) {
		this.adminPass = adminPass;
	}

	@Override
	public String toString() {
		return "Admin [adminPass=" + adminPass + "]";
	}
	
	
	
	
}
