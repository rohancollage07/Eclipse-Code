package com.payments;

public class Atm {
	private int atmNum;
	private int atmPass;
	private int atmBalance;
	
	public Atm() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Atm(int atmNum, int atmPass, int atmBalance) {
		super();
		this.atmNum = atmNum;
		this.atmPass = atmPass;
		this.atmBalance = atmBalance;
	}

	public int getAtmNum() {
		return atmNum;
	}

	public void setAtmNum(int atmNum) {
		this.atmNum = atmNum;
	}

	public int getAtmPass() {
		return atmPass;
	}

	public void setAtmPass(int atmPass) {
		this.atmPass = atmPass;
	}

	public int getAtmBalance() {
		return atmBalance;
	}

	public void setAtmBalance(int atmBalance) {
		this.atmBalance = atmBalance;
	}

	@Override
	public String toString() {
		return "Atm [atmNum=" + atmNum + ", atmPass=" + atmPass + ", atmBalance=" + atmBalance + "]";
	}
	
	
	
}
