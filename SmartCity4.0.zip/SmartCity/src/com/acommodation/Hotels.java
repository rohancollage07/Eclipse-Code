package com.acommodation;

public class Hotels {
	
	private int hId;
	private String hName;
	private String hAddress;
	private String hArea;
	private int hPrice;
	private int roomAvail;
	
	public Hotels() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hotels(int hId, String hName, String hAddress, String hArea, int hPrice, int roomAvail) {
		super();
		this.hId = hId;
		this.hName = hName;
		this.hAddress = hAddress;
		this.hArea = hArea;
		this.hPrice = hPrice;
		this.roomAvail = roomAvail;
	}

	public int gethId() {
		return hId;
	}

	public void sethId(int hId) {
		this.hId = hId;
	}

	public String gethName() {
		return hName;
	}

	public void sethName(String hName) {
		this.hName = hName;
	}

	public String gethAddress() {
		return hAddress;
	}

	public void sethAddress(String hAddress) {
		this.hAddress = hAddress;
	}

	public String gethArea() {
		return hArea;
	}

	public void sethArea(String hArea) {
		this.hArea = hArea;
	}

	public int gethPrice() {
		return hPrice;
	}

	public void sethPrice(int hPrice) {
		this.hPrice = hPrice;
	}

	public int getRoomAvail() {
		return roomAvail;
	}

	public void setRoomAvail(int roomAvail) {
		this.roomAvail = roomAvail;
	}

	@Override
	public String toString() {
		return "Hotel " + hId + ": \n"
	            + "HotelName: " + hName + ",\n"
	            + "HotelAddress: " + hAddress + ",\n"
	            + "HotelArea: " + hArea + ",\n"
	            + "Price per Room: " + hPrice + ",\n"
	            + "Rooms Available: " + roomAvail + "\n";
	}
	
	
	
	

}
