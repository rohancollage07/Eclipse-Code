package com.controller;

import java.util.Scanner;

import com.service.Service;

public class Controller {
	
	static Service service = new Service();
	
	public static void filterByPrice() {
		service.filterByPrice();
	}
	public static void filterByArea() {
		service.filterByArea();
	}
	
	public static void bookHotel(int hId) {
		service.bookHotelById(hId);
	}
	
	public static void cancelHotel(int hId) {
		service.cancelHotelById(hId);
	}
	
	
	public static void fetchNews() {
		service.fetchNews();
	}
	
	public static void filterNewsById(int nId) {
		service.filterNewsById(nId);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Rohan's City ! What would you explore : ");
		System.out.println();
		System.out.print("Hotel ? press 1 ");
		System.out.println();
		System.out.print("City News ? press 2 ");
		System.out.println();
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			
			service.fetchHotels();
			System.out.println();
			System.out.println("filter hotels : ");
			System.out.println();
			System.out.println("price ? press 1");
			
			System.out.println("area ? press 2 ");
			int choice2 = sc.nextInt();
			
			switch (choice2) {
			case 1:
				filterByPrice();
				
				break;
			case 2 : 
				filterByArea();
				break;

			default:
				break;
			}
			
			System.out.println("which hotel to book? Enter id : ");
			int hId = sc.nextInt();
			
			bookHotel(hId);
			
			System.out.println("which hotel to Cancel? Enter id : ");
			int hId2 = sc.nextInt();
			
			cancelHotel(hId2);
			
			break;
		case 2: 
			fetchNews();
			
			System.out.println();
			
			System.out.println("which story would you like to read fully ? ");
			System.out.println("Enter ID: ");
			
			int nId = sc.nextInt();
			
			filterNewsById(nId);
			
			break;
		default:
			break;
		}
		
		
		
	}

}
