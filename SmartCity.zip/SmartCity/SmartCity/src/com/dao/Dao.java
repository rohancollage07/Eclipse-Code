package com.dao;

import java.util.ArrayList;
import java.util.Arrays;

import com.acommodation.Hotels;
import com.news.News;

public class Dao {
	
	ArrayList<Hotels> hList = new ArrayList<>(Arrays.asList(
			
			new Hotels(1,"ssbstay","street 1",
			"mankhurd",200,3),
			new Hotels(2,"akhotels","street 2",
					"chembur",250,4),
			
			new Hotels(3,"Swami","street 3",
					"Vashi",100,2)
			
			)
			
			);
		
	public ArrayList<Hotels> fetchHotels() {
		return hList;

	}
	
	
	ArrayList<News> nList = new ArrayList<>(Arrays.asList(
			
			new News(1, "Army personal dead at Kashmir", "Another jawan died on Thursday in the ongoing encounter between terrorists and security forces in Jammu and Kashmir's Rajouri district. This has taken the number of total Army personnel killed since yesterday to five.\r\n"
					+ "\r\n"
					+ "Four Army personnel were killed on Wednesday, which included two captains and two jawans."),
			
			new News(2, "People found who were missing in the tunnel",
					"A senior member of the National Disaster Management Authority (NDMA) on Thursday warned the masses against putting pressure on the rescue teams with their expectations of a hasty rescue of the 41 workers trapped in a partially collapsed tunnel in Uttarkashi. Lt General (retired) Syed Ata Hasnain, addressing a press conference, pointed out that the trapped workers and the rescuers are at equal risk and expecting the rescue operation to be completed in the “next two hours” exerts pressure on the latter. ")
			
			)
			
			);
	
	public ArrayList<News> fetchNews() {
		return nList;

	}

}
