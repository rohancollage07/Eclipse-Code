package com.news;

public class News {
	private int newsID;
	private String newsStory;
	private String fullStory;
	
	public News() {
		super();
		// TODO Auto-generated constructor stub
	}

	public News(int newsID, String newsStory, String fullStory) {
		super();
		this.newsID = newsID;
		this.newsStory = newsStory;
		this.fullStory = fullStory;
	}

	public int getNewsID() {
		return newsID;
	}

	public void setNewsID(int newsID) {
		this.newsID = newsID;
	}

	public String getNewsStory() {
		return newsStory;
	}

	public void setNewsStory(String newsStory) {
		this.newsStory = newsStory;
	}
	
	
	public String getFullStory() {
		return fullStory;
	}

	public void setFullStory(String fullStory) {
		this.fullStory = fullStory;
	}

	@Override
	public String toString() {
		return "News [newsID=" + newsID + ", newsStory=" + newsStory + ", fullStory=" + fullStory + "]";
	}
	
	
	
	
	
	
	
}
