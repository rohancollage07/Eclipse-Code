package com.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

import com.acommodation.Hotels;
import com.dao.Dao;
import com.news.News;

public class Service {
	static Dao da = new Dao();
	
	public ArrayList<Hotels> hlist  = da.fetchHotels();
	public ArrayList<News> nList  = da.fetchNews();
	
	public void fetchHotels() {
		
		hlist.forEach(System.out::println);
	}
	
	public void filterByPrice() {
		hlist.stream().sorted(Comparator.comparingInt(Hotels::gethPrice)).forEach(System.out::println);
		System.out.println();
	}
	
	public void filterByArea() {
		hlist.stream().sorted(Comparator.comparing(Hotels::gethArea, String.CASE_INSENSITIVE_ORDER)).forEach(System.out::println);
		
	}
	
	public void bookHotelById(int hId) {
		String result = hlist.stream()
			    .filter(x -> x.gethId() == hId)
			    .map(x -> "Booked hotel at : " + x.gethName()+ " Happy Stay !")
			    .findFirst()
			    .orElse("No hotel found with ID : " + hId + " Try Again");
	
			System.out.println(result);
			System.out.println();

	
	}
	
	
	public void cancelHotelById(int hId) {
		String result = hlist.stream()
			    .filter(x -> x.gethId() == hId)
			    .map(x -> "Booking cancel at : " + x.gethName()+ ", No problem visit next time")
			    .findFirst()
			    .orElse("No hotel found with ID : " + hId + " Try Again");
	
			System.out.println(result);
			System.out.println();
	
	}
	
	
	public void fetchNews() {
		
//		nList.forEach(System.out::println);
		nList.stream().map(x -> x.getNewsID() + " " +  x.getNewsStory()).collect(Collectors.toList()).forEach(System.out::println);;
	}
	
	
	public void filterNewsById(int nId) {
		 nList.stream().filter(x -> x.getNewsID() == nId).map(x -> x.getFullStory()).collect(Collectors.toList()).forEach(System.out::println);
		
	}
	
	
}


